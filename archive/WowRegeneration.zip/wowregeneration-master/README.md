WOW Regeneration
===============

Supported version :

4.3.4 (15595)

WoWRegeneration is now compatible with mono (on ubuntu at least) see using-mono.txt

Usage : just run.
