# ClientDownloader
Program to download base files for World of Warcraft 4.3.4.15595 (e.g Wow.exe) from Blizzard servers

# Dependience 
ASP.NET Core 3.1 Runtime (v3.1.13)
https://dotnet.microsoft.com/en-us/download/dotnet/3.1
